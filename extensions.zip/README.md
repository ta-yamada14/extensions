# BS helper

BSからの要望によって生まれたChrome拡張機能

## インストール方法

1. Chromeで `chrome://extensions/` を開く
2. 右上の「デベロッパーモード」をONにする
3. 「パッケージ化されていない拡張機能を読み込む」をクリック
4. このフォルダ（extensionsフォルダ）を選択
